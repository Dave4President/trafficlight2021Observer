package trafficlight;

public interface Observer {
    void update();
}
